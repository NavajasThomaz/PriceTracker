import json

Produtos = {
    1: {
        "titulo": "rtx 3090",
        "descrição": "Placa Grafica com RayTracing",
        "preço_R$": 15246.97,
        "estoque": 5
    },
    2: {
        "titulo": "TUF X670E-Plus",
        "descrição": "Placa Mãe",
        "preço_R$": 3062.80,
        "estoque": 7
    },
    3: {
        "titulo": "Ryzen 9 7950X",
        "descrição": "Processador",
        "preço_R$": 5000.00,
        "estoque": 2
    },
    4: {"titulo": "Memória DDR4 Corsair Vengeance RGB",
        "descrição": "DDR5 CL40 6800mhz 4x16gb",
        "preço_R$": 2350.00,
        "estoque": 4
        },
    5: {
        "titulo": "Water Cooler NZXT Kraken Elite 280",
        "descrição": "280mm",
        "preço_R$": 5000.00,
        "estoque": 2
    },
    6: {
        "titulo": "Fonte XPG, Core Reactor, 650W",
        "descrição": "1600W",
        "preço_R$": 5999.00,
        "estoque": 8
    },
    7: {
        "titulo": "SSD Adata Legend 970, 2TB",
        "descrição": "PCIe 3.1 R3300MB/s W2900MB/s",
        "preço_R$": 11309.99,
        "estoque": 4
    },
    8: {
        "titulo": "Monitor Gamer LG, 27 Pol",
        "descrição": "Monitor 1ms 144HZ 49pol",
        "preço_R$": 5000.00,
        "estoque": 2
    },
}

produtos_json = json.dumps(Produtos)

# with open("produtos.json", "w") as arquivo_json:
#     arquivo_json.write(produtos_json)