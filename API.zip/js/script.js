import { fetchCardData } from './home.js'

fetchCardData('./data/produtosTERABYTE.json')
